const db = require('../Config/db');

exports.getUsers = async (req, res) => {
  try {
    const [users] = await db.query('SELECT id, name, email, role, created_at FROM Users');
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateUserRole = async (req, res) => {
  const { id, role } = req.body;

  try {
    const [result] = await db.query('UPDATE Users SET role = ? WHERE id = ?', [role, id]);
    res.status(200).json({ message: 'User role updated successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Mendapatkan pengguna berdasarkan ID
exports.getUserById = async (req, res) => {
  const { id } = req.params;

  try {
    const [user] = await db.query('SELECT id, name, email, role, created_at FROM Users WHERE id = ?', [id]);
    if (user.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.status(200).json(user[0]);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Memperbarui peran pengguna berdasarkan ID
exports.updateUserRoleById = async (req, res) => {
  const { id } = req.params; // ID dari parameter URL
  const { role } = req.body; // Role dari body request

  try {
    const [result] = await db.query('UPDATE Users SET role = ? WHERE id = ?', [role, id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'User not found or no changes made' });
    }
    res.status(200).json({ message: 'User role updated successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};