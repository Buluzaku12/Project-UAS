const express = require('express');
const { getUsers, updateUserRole, getUserById, updateUserRoleById} = require('../Controllers/userController'); // Pastikan nama fungsi sesuai di controller
const { authenticateToken } = require('../Middlewares/authMiddleware'); // Pastikan middleware diimpor dengan benar
const router = express.Router();

// Mendapatkan semua pengguna 
router.get('/', getUsers);

// Memperbarui role pengguna (dengan otentikasi)
router.put('/role', authenticateToken, updateUserRole);

// Mendapatkan pengguna berdasarkan ID
router.get('/:id', authenticateToken, getUserById);

// Memperbarui peran pengguna berdasarkan ID
router.put('/:id/role', authenticateToken, updateUserRoleById);

module.exports = router;